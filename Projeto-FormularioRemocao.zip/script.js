<script>
  const formulario = document.getElementById('formulario');
  formulario.addEventListener('submit', (e) => {
    e.preventDefault();
    // código para enviar os dados do formulário para um servidor ou realizar outra ação
  });
</script>
  
